# The Sapphire Circle

A Pen created on CodePen.

Original URL: [https://codepen.io/lukesawczak/pen/KwwywKO/57fcc5f91e3ca9894f65b60ebe94baf1](https://codepen.io/lukesawczak/pen/KwwywKO/57fcc5f91e3ca9894f65b60ebe94baf1).

